/*! grafana - v3.1.0-1466707812beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a){return{setters:[function(a){}],execute:function(){}}});