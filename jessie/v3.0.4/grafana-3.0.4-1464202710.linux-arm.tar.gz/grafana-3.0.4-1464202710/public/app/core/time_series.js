/*! grafana - v3.0.4-1464202710 - 2016-05-25
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});