/*! grafana - v3.1.0-1466707812beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["app/core/settings"],function(a){"use strict";var b=window.grafanaBootData||{settings:{}},c=b.settings;return c.bootData=b,new a(c)});