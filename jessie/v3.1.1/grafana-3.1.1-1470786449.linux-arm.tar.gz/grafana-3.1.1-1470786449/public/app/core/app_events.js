/*! grafana - v3.1.1-1470786449 - 2016-08-10
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./utils/emitter"],function(a){var b,c;return{setters:[function(a){b=a}],execute:function(){c=new b.Emitter,a("default",c)}}});