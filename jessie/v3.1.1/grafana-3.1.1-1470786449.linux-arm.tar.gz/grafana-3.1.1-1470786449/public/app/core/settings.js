/*! grafana - v3.1.1-1470786449 - 2016-08-10
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["lodash"],function(a){"use strict";return function(b){var c={datasources:{},window_title_prefix:"Grafana - ",panels:{},new_panel_title:"Panel Title",playlist_timespan:"1m",unsaved_changes_warning:!0,appSubUrl:""};return a.extend({},c,b)}});