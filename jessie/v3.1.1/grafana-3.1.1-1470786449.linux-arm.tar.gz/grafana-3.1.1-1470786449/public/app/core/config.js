/*! grafana - v3.1.1-1470786449 - 2016-08-10
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["app/core/settings"],function(a){"use strict";var b=window.grafanaBootData||{settings:{}},c=b.settings;return c.bootData=b,new a(c)});