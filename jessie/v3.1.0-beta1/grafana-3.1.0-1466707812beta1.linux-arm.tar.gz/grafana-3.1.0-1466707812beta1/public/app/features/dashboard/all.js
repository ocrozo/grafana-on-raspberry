/*! grafana - v3.1.0-1466707812beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./dashboard_ctrl","./dashboardLoaderSrv","./dashnav/dashnav","./submenu/submenu","./saveDashboardAsCtrl","./rowCtrl","./shareModalCtrl","./shareSnapshotCtrl","./dashboardSrv","./keybindings","./viewStateSrv","./timeSrv","./unsavedChangesSrv","./timepicker/timepicker","./graphiteImportCtrl","./importCtrl","./impression_store","./upload","./import/dash_import","./export/export_modal","./dash_list_ctrl"],function(){});