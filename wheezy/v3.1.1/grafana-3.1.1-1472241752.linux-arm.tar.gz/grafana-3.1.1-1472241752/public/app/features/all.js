/*! grafana - v3.1.1-1472241752 - 2016-08-26
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panellinks/module","./dashlinks/module","./annotations/annotations_srv","./templating/templateSrv","./dashboard/all","./playlist/all","./snapshot/all","./panel/all","./styleguide/styleguide"],function(){});