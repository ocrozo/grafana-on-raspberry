/*! grafana - v3.0.3-1464034780 - 2016-05-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./panellinks/module","./dashlinks/module","./annotations/annotations_srv","./templating/templateSrv","./dashboard/all","./playlist/all","./snapshot/all","./panel/all","./styleguide/styleguide"],function(){});