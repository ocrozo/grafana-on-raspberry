/*! grafana - v3.1.0-1470780578 - 2016-08-09
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});