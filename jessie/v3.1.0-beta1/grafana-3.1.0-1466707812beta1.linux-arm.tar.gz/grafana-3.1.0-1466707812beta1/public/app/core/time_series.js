/*! grafana - v3.1.0-1466707812beta1 - 2016-06-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});