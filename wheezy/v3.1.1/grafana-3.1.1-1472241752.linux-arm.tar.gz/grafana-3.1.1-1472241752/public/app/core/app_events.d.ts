/// <reference path="../../../public/app/headers/common.d.ts" />
import { Emitter } from './utils/emitter';
declare var appEvents: Emitter;
export default appEvents;
