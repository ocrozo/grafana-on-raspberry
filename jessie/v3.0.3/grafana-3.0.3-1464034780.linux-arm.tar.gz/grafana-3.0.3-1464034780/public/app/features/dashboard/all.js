/*! grafana - v3.0.3-1464034780 - 2016-05-23
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./dashboardCtrl","./dashboardLoaderSrv","./dashnav/dashnav","./submenu/submenu","./saveDashboardAsCtrl","./rowCtrl","./shareModalCtrl","./shareSnapshotCtrl","./dashboardSrv","./keybindings","./viewStateSrv","./timeSrv","./unsavedChangesSrv","./timepicker/timepicker","./graphiteImportCtrl","./dynamicDashboardSrv","./importCtrl","./impression_store"],function(){});